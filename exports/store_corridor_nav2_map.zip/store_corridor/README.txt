Nav2 static map draft from user-provided dimensions, 2026-11-11.
Interior: 6.6 x 4.4 metres. Obstacle: x=[1.6,6.6], y=[1.4,3.0].
PGM and YAML belong together. PGM is occupancy; preview PNG/SVG has labels and is not occupancy.
Resolution: 0.05 m/cell. Raster origin: [-0.05,-0.05,0], includes one outside border cell.
Coordinates (0,0) are the inside bottom-left corner.
Not surveyed/calibrated. A real robot needs localization, live obstacles, odometry/TF and verified footprint.
Geometry YAML initial_pose is for fake simulation only.
